
package Model;
import java.sql.Date;
/**
 *
 * @author chung
 */
public class announcement {
    private int announcementID;
    private String LibrarionID;
    private String title;
    private String content;
    private int tag;
    private Date a;

    public announcement() {
    }

    public announcement(int announcementID, String LibrarionID, String title, String content, int tag, Date a) {
        this.announcementID = announcementID;
        this.LibrarionID = LibrarionID;
        this.title = title;
        this.content = content;
        this.tag = tag;
        this.a = a;
    }

    public int getAnnouncementID() {
        return announcementID;
    }

    public void setAnnouncementID(int announcementID) {
        this.announcementID = announcementID;
    }

    public String getLibrarionID() {
        return LibrarionID;
    }

    public void setLibrarionID(String LibrarionID) {
        this.LibrarionID = LibrarionID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public Date getA() {
        return a;
    }

    public void setA(Date a) {
        this.a = a;
    }

    
   
}
