/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chung.sendEmail;

/**
 *
 * @author chung
 */
public  class add {
    public static int add(int a){
        return a+2;
    }
}
