package controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author chung
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author heaty566
 */
public class Constants {

	public static String GOOGLE_CLIENT_ID = "1051044406552-3bcjp6hs28bkl9m7cspjvdpfuitb3fcn.apps.googleusercontent.com";

	public static String GOOGLE_CLIENT_SECRET = "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";

	public static String GOOGLE_REDIRECT_URI = "http://localhost:8080/2_SWPonlineLibrary/login";

	public static String GOOGLE_LINK_GET_TOKEN = "https://accounts.google.com/o/oauth2/token";

	public static String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v3/userinfo?access_token=";

	public static String GOOGLE_GRANT_TYPE = "authorization_code";

}
