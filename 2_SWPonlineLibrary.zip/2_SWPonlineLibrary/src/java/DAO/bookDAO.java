/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.DBContext;
import Model.book;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author chung
 */
public class bookDAO extends DBContext{
    
    public book getBookByPartialName(String pn){
        book b =null;
        
         try {
            st = connection.prepareStatement("select *from Book where Bname like ?");
            st.setString(1, "%"+pn+"%");
            ResultSet rs = st.executeQuery();
            
                if(rs.next()){
                    b= new book(rs.getInt(1), rs.getString(2), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getInt(8), rs.getInt(9), rs.getString(10));
               
                }
           
        } catch (Exception e) {
            System.out.println("Error in get book");
        }
         return b;
        
        
        
    }
    
    
    public List<book> getAllBook(){
        String sql="select * from Book";
        List<book> ls = new ArrayList<>();
        try {
            st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (true) {
                if(rs.next()){
                    ls.add(new book(rs.getInt(1), rs.getString(2), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getInt(8), rs.getInt(9), rs.getString(10)));
                }else break;
            }
        } catch (Exception e) {
            System.out.println("Error in get all book");
        }
        
        
        return ls;
    }
    
    
    public static void main(String[] args) {
        bookDAO bd = new bookDAO();
        book b=bd.getBookByPartialName("lazy");
            System.out.println(b.getBookName());
        
    }
}
