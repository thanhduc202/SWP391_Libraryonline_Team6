/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.DBContext;
import Model.account;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author chung
 */
public class accountDAO extends DBContext{
   
    public account getAccoutByAccountName(String name){
        account a ;
        String sql ="select * from Account where AccountName =?";
        try {
            st = connection.prepareCall(sql);
            st.setString(1, name);
            ResultSet rs = st.executeQuery();
            if(rs.next()){
                a= new account(rs.getString(1), rs.getString(2), rs.getString(3), rs.getBoolean(4), rs.getLong(4), rs.getInt(5), rs.getInt(6));
                return a;
            }
            else{
                return null;
            }
        } catch (Exception e) {
            Logger.getLogger(accountDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }       
    }
    
    public boolean accountVerificationByNameAndPassword(String name, String password){
        String realPassword = getAccoutByAccountName(name).getPassword();
        return password.equals(realPassword);
             
    }
    
    public boolean accountVerificationByName(String name){
        String realAccountName = getAccoutByAccountName(name).getAccName();
        return realAccountName.equals(name);
             
    }

    
    
    
    public static void main(String[] args) {
       accountDAO ad = new accountDAO();
        System.out.println(ad.accountVerificationByNameAndPassword("chung@gmail.com", "123"));
        System.out.println(ad.accountVerificationByName("chung@gmail.com"));
       // System.out.println(ad.getAccoutByAccountName("hoang@gmail.com").getFullName());
      // account expect = new account("chung@gmail.com", "123", "do van chung", true, 123123123, 1, 1);
     
      
    }
    
    
    
}
