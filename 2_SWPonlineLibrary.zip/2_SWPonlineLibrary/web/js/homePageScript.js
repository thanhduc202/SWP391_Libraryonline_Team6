function moveIn(x){
    x.style.animation="traslution 0.5s forwards ease";
}
function moveOut(x){
    x.style.animation="untraslution 0.7s forwards ease";
}


