/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.chung.sendEmail;

import DAO.accountDAO;
import Model.account;
import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author chung
 */
public class TestAccount {
    
    public TestAccount() {
    }
       @Test
    public void testGetAccountByName(){
        String input = "chung@gmail.com";
        account expect = new account("chung@gmail.com", "123", "do van chung", true, 123123123, 1, 1);
        accountDAO ad = new accountDAO();
        account actual = ad.getAccoutByAccountName(input);
        Assert.assertEquals(expect.getAccName(), actual.getAccName());
        Assert.assertEquals(expect.getPassword(), actual.getPassword());
        
    }
    @Test
    public void loginWithUserNameAndPassword(){
        String name= "chung@gmail.com";
        String password = "123";
        accountDAO ad = new accountDAO();
        boolean expect = true;
        boolean actual= ad.accountVerificationByNameAndPassword(name, password);
        Assert.assertEquals(expect,actual);
    }
    @Test
    public void loginWithGoogle(){
        String name= "chung@gmail.com";

        accountDAO ad = new accountDAO();
        boolean expect = true;
        boolean actual= ad.accountVerificationByName(name);
        Assert.assertEquals(expect,actual);
    }
    
    
}
