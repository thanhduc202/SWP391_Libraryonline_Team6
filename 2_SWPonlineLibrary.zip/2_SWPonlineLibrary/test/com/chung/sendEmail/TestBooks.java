/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.chung.sendEmail;

import DAO.accountDAO;
import DAO.announcementDAO;
import DAO.bookDAO;
import Model.account;
import Model.book;
import java.util.List;

import org.junit.Test;

import org.junit.Assert;

/**
 *
 * @author chung
 */
public class TestBooks {
    
    public TestBooks() {
    }
    
 
    
    @Test
    public void testGetAllBook(){
        
        
        bookDAO bd = new bookDAO();
        List<book> ls = bd.getAllBook();
        Assert.assertEquals("Lazy diary",ls.get(0).getBookName() );
        Assert.assertEquals("firebase",ls.get(1).getBookName());
    }
    @Test
     public void testGetBookByPatialName(){
        String input = "lazy";
        
        bookDAO bd = new bookDAO();
        book b = bd.getBookByPartialName(input);
        Assert.assertEquals("Lazy diary",b.getBookName() );
        
    }
    
 
    
}
