/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package controller;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author chung
 */
public class LoginGoogleHandlerTest {
    
    public LoginGoogleHandlerTest() {
    }

    @Test
    public void testSomeMethod() {
    }
    
}
