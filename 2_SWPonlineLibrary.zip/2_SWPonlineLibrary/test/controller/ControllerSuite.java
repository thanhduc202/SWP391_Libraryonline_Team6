/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package controller;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author chung
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({controller.LoginGoogleHandlerTest.class, controller.UserGoogleDtoTest.class, controller.ConstantsTest.class})
public class ControllerSuite {
    
}
